
import React from "react";
import EnhancedGPSMap from "./EnhancedGPSMap";

const GPSMapWidget = () => {
  return <EnhancedGPSMap />;
};

export default GPSMapWidget;
